

<?php $__env->startSection('panel'); ?>

    <div class="row">

        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">
                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Ip'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Ip'); ?>"><?php echo e($log->ip); ?></td>
                                <td data-label="<?php echo app('translator')->get('Date'); ?>"><?php echo e(showDateTime($log->created_at,'d M Y')); ?></td>
                                <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                    <a href="javascript:void(0)" data-route="<?php echo e(route('admin.advertise.ip.unblock',$log->id)); ?>" class="icon-btn btn--primary block" data-toggle="tooltip" title="<?php echo app('translator')->get('Un Block IP'); ?>">
                                        <i class="las la-check text--shadow"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e($empty_message); ?></td>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>
                <div class="card-footer py-4">
                    <?php echo e(paginateLinks($logs)); ?>

                </div>
            </div><!-- card end -->
        </div>

        <div class="modal fade" id="unblockModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
               <button type="button" class="close ml-auto m-3" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body text-center">
                            
                            <i class="las la-exclamation-circle text-secondary display-2 mb-15"></i>
                            <h4 class="text--secondary mb-15"><?php echo app('translator')->get('Are You Sure Want to Un Block This Ip?'); ?></h4>
    
                        </div>
                    <div class="modal-footer justify-content-center">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->get('close'); ?></button>
                      <button type="submit"  class="btn btn--success del"><?php echo app('translator')->get('Un Block'); ?></button>
                    </div>
                    
                    </form>
              </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<script>
    'use strict';
    $('.block').on('click',function(){
        var route = $(this).data('route')
        var modal = $('#unblockModal');
        modal.find('form').attr('action',route)
        modal.modal('show');


    })
</script>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <form action="" method="GET" class="form-inline float-sm-right bg--white">
        <div class="input-group has_append">
            <input type="text" name="search" class="form-control" placeholder="<?php echo app('translator')->get('Ip'); ?>" value="<?php echo e($search??''); ?>" autocomplete="off">
            <div class="input-group-append">
                <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
            </div>
        </div>
    </form>    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/admin/advertises/blocked_ip_logs.blade.php ENDPATH**/ ?>