  <?php
      $adFormat = getContent('format.content',true);
      $adFormats = getContent('format.element',false);
  ?>
  
  <!-- ad format section start -->
    <section class="pt-100 pb-100 bg_img overlay--one" data-background="<?php echo e(getImage('assets/images/frontend/format/'.@$adFormat->data_values->background_image,'1920x1080')); ?>">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-6">
              <div class="section-header text-center">
                <h2 class="section-title text-white"><?php echo app('translator')->get($adFormat->data_values->heading); ?></h2>
              </div>
            </div>
          </div>
          <div class="row justify-content-between">
            <div class="col-lg-12 mb-5">
              <ul class="nav nav-pills side-tab-nav style--white justify-content-center" id="pills-tab" role="tablist">
                  <?php $__currentLoopData = $adFormats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aditem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="nav-item" role="presentation">
                    <a class="nav-link <?php echo e($loop->first?'active':''); ?>" id="<?php echo e('ad'.$loop->iteration); ?>" data-toggle="pill" href="<?php echo e('#item'.$loop->iteration); ?>" role="tab" aria-controls="banner" aria-selected="true"></i><?php echo app('translator')->get($aditem->data_values->heading); ?></a>
                  </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <div class="col-lg-12">
              <div class="tab-content white-glass-bg glass--shadow py-5 px-4 border-radius--8" id="pills-tabContent">
                <?php $__currentLoopData = $adFormats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adformat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade show <?php echo e($loop->first?'active':''); ?>" id="<?php echo e('item'.$loop->iteration); ?>" role="tabpanel" aria-labelledby="<?php echo e('ad'.$loop->iteration); ?>">
                  <div class="ad-format-details">
                    <div class="row align-items-center">
                      <div class="col-lg-6">
                        <div class="thumb">
                          <img src="<?php echo e(getImage('assets/images/frontend/format/'.@$adformat->data_values->image,'516x283')); ?>" alt="ad" class="border-radius--5">
                        </div>
                      </div>
                      <div class="col-lg-6 mt-lg-0 mt-4">
                        <div class="content">
                          <h3 class="title text-white"><?php echo app('translator')->get($adformat->data_values->heading); ?></h3>
                          <p class="mt-3 text-white"><?php echo app('translator')->get($adformat->data_values->short_details); ?></p>
                        
                        </div>
                      </div>
                    </div>
                  </div><!-- ad-format-details end -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- ad format section end --><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/templates/basic/sections/format.blade.php ENDPATH**/ ?>