<?php $__env->startSection('panel'); ?>
    <div class="row">

        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">
                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Name'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Price'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Type'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Credit'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Actions'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Name'); ?>" class="text--primary"><?php echo e($plan->name); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Price'); ?>"><span
                                            class="badge  bg--primary"><?php echo e($general->cur_sym); ?> <?php echo e(getAmount($plan->price)); ?></span>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Type'); ?>"><span
                                            class="text--small badge font-weight-normal <?php echo e($plan->type=='click' ? 'badge--dark':'badge--warning'); ?> bg--"><?php echo e(ucfirst($plan->type)); ?></span>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Credit'); ?>"><span
                                            class="badge badge-pill bg--secondary"><?php echo e(getAmount($plan->credit)); ?></span>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Status'); ?>"><span
                                            class="text--small badge font-weight-normal <?php echo e($plan->status ==1 ?'badge--success':'badge--warning'); ?>"><?php echo e($plan->status ==1?'Active':'Deactive'); ?></span>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Actions'); ?>">
                                        <button type="button" class="icon-btn btn--primary edit"
                                                data-name="<?php echo e($plan->name); ?>"
                                                data-price="<?php echo e(getAmount($plan->price,2)); ?>"
                                                data-type="<?php echo e($plan->type); ?>"
                                                data-credit="<?php echo e(getAmount($plan->credit)); ?>"
                                                data-status="<?php echo e($plan->status); ?>"
                                                data-route="<?php echo e(route('admin.advertise.update.price-plan',$plan->id)); ?>">
                                            <i class="las la-pen text--shadow"></i>
                                        </button>

                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e($empty_message); ?></td>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>
            </div><!-- card end -->
        </div>

        <!--add modal-->
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
             aria-hidden="true">
            <div class="modal-dialog" role="document">
                <form action="<?php echo e(route('admin.advertise.add.price-plan')); ?>" method="POST" enctype="multipart/form-data">
                    <div class="modal-content">
                        <div class="modal-header btn--primary">
                            <h5 class="modal-title text-white" id="exampleModalLabel"><?php echo app('translator')->get('Add new Plan'); ?></h5>
                            <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group ">
                                        <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Name'); ?><span
                                                class="text-danger">*</span></label>
                                        <input class="form-control" placeholder="<?php echo e(trans('Plan name')); ?>" type="text"
                                               name="name" value="<?php echo e(old('name')); ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Price'); ?><span
                                            class="text-danger">*</span></label>
                                    <div class="form-group  input-group has_append">
                                        <input type="text" class="form-control" placeholder="<?php echo e(trans('Price')); ?>"
                                               name="price" required value="<?php echo e(old('price')); ?>">
                                        <div class="input-group-append">
                                            <div class="input-group-text"><?php echo e($general->cur_text); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Type'); ?><span
                                                class="text-danger">*</span></label>
                                        <select name="type" class="form-control">
                                            <option><?php echo app('translator')->get('--select type--'); ?></option>
                                            <option value="impression"><?php echo app('translator')->get('Impression'); ?></option>
                                            <option value="click"><?php echo app('translator')->get('Click'); ?></option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Credit'); ?><span
                                                class="text-danger">*</span></label>
                                        <input class="form-control" type="text" placeholder="<?php echo e(trans('Credit')); ?>"
                                               name="credit" value="<?php echo e(old('credit')); ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <li class="list-group-item d-flex justify-content-between align-items-center font-weight-bold">
                                    <?php echo app('translator')->get(' Status:'); ?>
                                    <label class="switch">
                                        <input type="checkbox" name="status" id="checkbox">
                                        <div class="slider round"></div>
                                    </label>
                                </li>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                            <button type="submit" class="btn btn--primary"><?php echo app('translator')->get('Save changes'); ?></button>
                        </div>
                    </div>
                </form>

            </div>
        </div>


        <!--edit modal-->
        <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
             aria-hidden="true">
            <div class="modal-dialog" role="document">
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="modal-content">
                        <div class="modal-header btn--primary">
                            <h5 class="modal-title text-white" id="exampleModalLabel"><?php echo app('translator')->get('Edit Plans'); ?></h5>
                            <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group ">
                                        <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Name'); ?><span
                                                class="text-danger">*</span></label>
                                        <input class="form-control" placeholder="<?php echo e(trans('Plan name')); ?>" type="text"
                                               name="name" value="" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Price'); ?><span
                                            class="text-danger">*</span></label>
                                    <div class="form-group  input-group has_append">
                                        <input type="text" class="form-control" placeholder="<?php echo e(trans('Price')); ?>"
                                               name="price" required value="">
                                        <div class="input-group-append">
                                            <div class="input-group-text"><?php echo e($general->cur_sym); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Type'); ?><span
                                                class="text-danger">*</span></label>
                                        <select name="type" class="form-control">
                                            <option><?php echo app('translator')->get('--Select type--'); ?></option>
                                            <option value="impression"><?php echo app('translator')->get('Impression'); ?></option>
                                            <option value="click"><?php echo app('translator')->get('Click'); ?></option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Credit'); ?><span
                                                class="text-danger">*</span></label>
                                        <input class="form-control" placeholder="<?php echo e(trans('Credit')); ?>" type="text"
                                               name="credit" value="" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <li class="list-group-item d-flex justify-content-between align-items-center font-weight-bold">
                                    <?php echo app('translator')->get('Status:'); ?>
                                    <label class="switch">
                                        <input type="checkbox" name="status">
                                        <div class="slider round"></div>
                                    </label>
                                </li>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                            <button type="submit" class="btn btn--primary"><?php echo app('translator')->get('Save changes'); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('breadcrumb-plugins'); ?>
    <button type="button" class="btn btn--primary" data-toggle="modal" data-target="#addModal"><i
            class="fas fa-plus"></i>
        <?php echo app('translator')->get('Add new Plan'); ?>
    </button>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

    <script>
        'use strict';
        var modal = $('#editModal');
        $('.edit').on('click', function () {
            var name = $(this).data('name');
            var price = $(this).data('price')
            var type = $(this).data('type')
            var credit = $(this).data('credit')
            var status = $(this).data('status')
            var route = $(this).data('route')

            modal.find('input[name=name]').val(name)
            modal.find('input[name=price]').val(price)
            modal.find('select[name=type]').val(type)

            modal.find('input[name=credit]').val(credit)
            if (status == 1) {
                modal.find('input[name=status]').attr('checked', 'checked')
            }
            modal.find('form').attr('action', route)
            modal.modal('show')
        })
    </script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/admin/advertises/pricePlan.blade.php ENDPATH**/ ?>