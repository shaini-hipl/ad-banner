<?php $__env->startSection('panel'); ?>
    <?php if(@json_decode($general->sys_version)->version > systemDetails()['version']): ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card text-white bg-warning mb-3">
                    <div class="card-header">
                        <h3 class="card-title"> <?php echo app('translator')->get('New Version Available'); ?> <button class="btn btn--dark float-right"><?php echo app('translator')->get('Version'); ?> <?php echo e(json_decode($general->sys_version)->version); ?></button> </h3>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title text-dark"><?php echo app('translator')->get('What is the Update ?'); ?></h5>
                        <p><pre  class="f-size--24"><?php echo e(json_decode($general->sys_version)->details); ?></pre></p>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if(@json_decode($general->sys_version)->message): ?>
        <div class="row">
            <?php $__currentLoopData = json_decode($general->sys_version)->message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12">
                    <div class="alert border border--primary" role="alert">
                        <div class="alert__icon bg--primary"><i class="far fa-bell"></i></div>
                        <p class="alert__message"><?php echo $msg; ?></p>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <div class="row mb-none-30">
        <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="dashboard-w1 bg--primary b-radius--10 box-shadow">
                <div class="icon">
                    <i class="fa fa-users"></i>
                </div>
                <div class="details">
                    <div class="numbers">
                        <span class="amount"><?php echo e($widget['total_users']); ?></span>
                    </div>
                    <div class="desciption">
                        <span class="text--small"><?php echo app('translator')->get('Total Advertiser'); ?></span>
                    </div>
                    <a href="<?php echo e(route('admin.advertiser.all')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                </div>
            </div>
        </div><!-- dashboard-w1 end -->
        <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="dashboard-w1 bg--success b-radius--10 box-shadow">
                <div class="icon">
                    <i class="fa fa-users"></i>
                </div>
                <div class="details">
                    <div class="numbers">
                        <span class="amount"><?php echo e($widget['total_publisher']); ?></span>
                    </div>
                    <div class="desciption">
                        <span class="text--small"><?php echo app('translator')->get('Total Publisher'); ?></span>
                    </div>
                    <a href="<?php echo e(route('admin.publisher.all')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="dashboard-w1 bg--deep-purple b-radius--10 box-shadow ">
                <div class="icon">
                    <i class="la la-envelope"></i>
                </div>
                <div class="details">
                    <div class="numbers">
                        <span class="amount"><?php echo e($widget['total_ads']); ?></span>
                    </div>
                    <div class="desciption">
                        <span class="text--small"><?php echo app('translator')->get('Total Advertises'); ?></span>
                    </div>

                    <a href="<?php echo e(route('admin.advertise.all')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                </div>
            </div>
        </div><!-- dashboard-w1 end -->
        <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="dashboard-w1 bg--warning b-radius--10 box-shadow ">
                <div class="icon">
                    <i class="fab fa-adn"></i>
                </div>
                <div class="details">
                    <div class="numbers">
                        <span class="amount"><?php echo e($widget['ad_type']); ?></span>
                    </div>
                    <div class="desciption">
                        <span class="text--small"><?php echo app('translator')->get('Total Ad Types'); ?></span>
                    </div>

                    <a href="<?php echo e(route('admin.advertise.type')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                </div>
            </div>
        </div><!-- dashboard-w1 end -->


        <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="dashboard-w1 bg--17 b-radius--10 box-shadow" >
                <div class="icon">
                    <i class="fa fa-list"></i>
                </div>
                <div class="details">
                    <div class="numbers">
                        <span class="amount"><?php echo e($payment['total_plan']); ?> </span>
                    </div>
                    <div class="desciption">
                        <span><?php echo app('translator')->get('Total Price Plans'); ?></span>
                    </div>
                    <a href="<?php echo e(route('admin.advertise.price-plan')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="dashboard-w1 bg--16 b-radius--10 box-shadow" >
                <div class="icon">
                    <i class="fa fa-globe"></i>
                </div>
                <div class="details">
                    <div class="numbers">
                        <span class="amount"><?php echo e($approvedDomain); ?> </span>

                    </div>
                    <div class="desciption">
                        <span><?php echo app('translator')->get('Total Approved Domains'); ?></span>
                    </div>
                    <a href="<?php echo e(route('admin.domain.approved')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="dashboard-w1 bg--1 b-radius--10 box-shadow" >
                <div class="icon">
                    <i class="fa fa-globe"></i>
                </div>
                <div class="details">
                    <div class="numbers">
                        <span class="amount"><?php echo e($pendingDomain); ?> </span>

                    </div>
                    <div class="desciption">
                        <span><?php echo app('translator')->get('Total Pending Domains'); ?></span>
                    </div>
                    <a href="<?php echo e(route('admin.domain.pending')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="dashboard-w1 bg--15 b-radius--10 box-shadow" >
                <div class="icon">
                    <i class="fas fa-hand-point-up"></i>
                </div>
                <div class="details">
                    <div class="numbers">
                        <span class="amount"><?php echo e(number_format_short($total_click)); ?> </span>

                    </div>
                    <div class="desciption">
                        <span><?php echo app('translator')->get('Total Clicked'); ?></span>
                    </div>
                    <a href="<?php echo e(route('admin.advertise.all')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
            <div class="dashboard-w1 bg--13 b-radius--10 box-shadow" >
                <div class="icon">
                    <i class="fas fa-eye"></i>
                </div>
                <div class="details">
                    <div class="numbers">
                        <span class="amount"><?php echo e(number_format_short($total_imp)); ?> </span>
                    </div>
                    <div class="desciption">
                        <span><?php echo app('translator')->get('Total Impressions'); ?></span>
                    </div>
                    <a href="<?php echo e(route('admin.advertise.all')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                </div>
            </div>
         </div>

            <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                <div class="dashboard-w1 bg--indigo b-radius--10 box-shadow" >
                    <div class="icon">
                        <i class="fa fa-wallet"></i>
                    </div>
                    <div class="details">
                        <div class="numbers">
                            <span class="amount"><?php echo e($paymentWithdraw['withdraw_method']); ?></span>
                        </div>
                        <div class="desciption">
                            <span><?php echo app('translator')->get('Withdraw Method'); ?></span>
                        </div>
                        <a href="<?php echo e(route('admin.withdraw.method.index')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                    </div>
                </div>
            </div>


            <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                <div class="dashboard-w1 bg--purple b-radius--10 box-shadow" >
                    <div class="icon">
                        <i class="fa fa-hand-holding-usd"></i>
                    </div>
                     <div class="details">
                        <div class="numbers">
                            <span class="amount"><?php echo e(getAmount($paymentWithdraw['total_withdraw_amount'])); ?></span>
                            <span class="currency-sign"><?php echo e($general->cur_text); ?></span>
                        </div>
                        <div class="desciption">
                            <span><?php echo app('translator')->get('Total Withdraw'); ?></span>
                        </div>
                        <a href="<?php echo e(route('admin.withdraw.approved')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                    </div>
                </div>
            </div>


            <div class="col-xl-3 col-lg-6 col-sm-4 mb-30">
                <div class="dashboard-w1 bg--teal b-radius--10 box-shadow">
                    <div class="icon">
                        <i class="fa fa-spinner"></i>
                    </div>
                    <div class="details">
                        <div class="numbers">
                            <span class="amount"><?php echo e($paymentWithdraw['total_withdraw_pending']); ?></span>
                        </div>
                        <div class="desciption">
                            <span><?php echo app('translator')->get('Withdraw Pending'); ?></span>
                        </div>

                        <a href="<?php echo e(route('admin.withdraw.pending')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                <div class="dashboard-w1 bg--brown b-radius--10 box-shadow" >
                    <div class="icon">
                        <i class="fa fa-money-bill-alt"></i>
                    </div>
                    <div class="details">
                        <div class="numbers">
                            <span class="amount"><?php echo e($paymentWithdraw['total_withdraw_approved']); ?> </span>
                        </div>
                        <div class="desciption">
                            <span><?php echo app('translator')->get('Withdraw Approved'); ?></span>
                        </div>
                        <a href="<?php echo e(route('admin.withdraw.approved')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                <div class="dashboard-w1 bg--12 b-radius--10 box-shadow" >
                    <div class="icon">
                        <i class="fa fa-money-bill-alt"></i>
                    </div>
                    <div class="details">
                        <div class="numbers">
                            <span class="amount"><?php echo e(getAmount($general->cpc)); ?> </span>
                            <span class="currency-sign"><?php echo e($general->cur_text); ?></span>
                        </div>
                        <div class="desciption">
                            <span><?php echo app('translator')->get('Current CPC'); ?></span>
                        </div>
                        <a href="<?php echo e(route('admin.advertise.perCost')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View'); ?></a>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                <div class="dashboard-w1 bg--8 b-radius--10 box-shadow" >
                    <div class="icon">
                        <i class="fa fa-money-bill-alt"></i>
                    </div>
                    <div class="details">
                        <div class="numbers">
                            <span class="amount"><?php echo e(getAmount($general->cpm)); ?> </span>
                            <span class="currency-sign"><?php echo e($general->cur_text); ?></span>
                        </div>
                        <div class="desciption">
                            <span><?php echo app('translator')->get('Current CPM'); ?></span>
                        </div>
                        <a href="<?php echo e(route('admin.advertise.perCost')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View'); ?></a>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                <div class="dashboard-w1 bg--19 b-radius--10 box-shadow" >
                    <div class="icon">
                        <i class="fas fa-ticket-alt"></i>
                    </div>
                    <div class="details">
                        <div class="numbers">
                            <span class="amount"><?php echo e($pendingTicket); ?> </span>
                        </div>
                        <div class="desciption">
                            <span><?php echo app('translator')->get('Total Pending Tickets'); ?></span>
                        </div>
                        <a href="<?php echo e(route('admin.ticket.pending')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3"><?php echo app('translator')->get('View All'); ?></a>
                    </div>
                </div>
            </div>
          </div><!-- row end-->


    <div class="row mt-50 mb-none-30">
        <div class="col-xl-6 mb-30">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo app('translator')->get('Monthly  Deposit & Withdraw  Report'); ?></h5>
                    <div id="apex-bar-chart"> </div>
                </div>
            </div>
        </div>
        <div class="col-xl-6 mb-30">
            <div class="row mb-none-30">
                <div class="col-lg-6 col-sm-6 mb-30">
                    <div class="widget-three box--shadow2 b-radius--5 bg--white">
                        <div class="widget-three__icon b-radius--rounded bg--primary box--shadow2">
                            <i class="las la-wallet "></i>
                        </div>
                        <div class="widget-three__content">
                            <h2 class="numbers"><?php echo e($payment['payment_method']); ?></h2>
                            <p  class="text--small"><?php echo app('translator')->get('Total Payment Method'); ?></p>
                        </div>
                    </div><!-- widget-two end -->
                </div>
                <div class="col-lg-6 col-sm-6 mb-30">
                    <div class="widget-three box--shadow2 b-radius--5 bg--white">
                        <div class="widget-three__icon b-radius--rounded bg--pink  box--shadow2">
                            <i class="las la-money-bill "></i>
                        </div>
                        <div class="widget-three__content">
                            <h2 class="numbers"><?php echo e(getAmount($payment['total_deposit_amount'])); ?> <?php echo e($general->cur_text); ?></h2>
                            <p class="text--small"><?php echo app('translator')->get('Total Deposit'); ?></p>
                        </div>
                    </div><!-- widget-two end -->
                </div>
                <div class="col-lg-6 col-sm-6 mb-30">
                    <div class="widget-three box--shadow2 b-radius--5 bg--white">
                        <div class="widget-three__icon b-radius--rounded bg--teal box--shadow2">
                            <i class="las la-money-check"></i>
                        </div>
                        <div class="widget-three__content">
                            <h2 class="numbers"><?php echo e(getAmount($payment['total_deposit_charge'])); ?> <?php echo e($general->cur_text); ?></h2>
                            <p class="text--small"><?php echo app('translator')->get('Total Deposit Charge'); ?></p>
                        </div>
                    </div><!-- widget-two end -->
                </div>
                <div class="col-lg-6 col-sm-6 mb-30">
                    <div class="widget-three box--shadow2 b-radius--5 bg--white">
                        <div class="widget-three__icon b-radius--rounded bg--green  box--shadow2">
                            <i class="las la-money-bill-wave "></i>
                        </div>
                        <div class="widget-three__content">
                            <h2 class="numbers"><?php echo e($payment['total_deposit_pending']); ?></h2>
                            <p class="text--small"><?php echo app('translator')->get('Pending Deposit'); ?></p>
                        </div>
                    </div><!-- widget-two end -->
                </div>
            </div>
        </div>
    </div><!-- row end -->

    <div class="row mb-none-30 mt-5">
        <div class="col-xl-12 mb-30">
            <div class="card ">
                <div class="card-header">
                    <h6 class="card-title mb-0"><?php echo app('translator')->get('Latest Transactions'); ?></h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive--sm table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('TRX'); ?></th>

                                <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Charge'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Post Balance'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Detail'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="Date"><?php echo e(showDateTime($trx->created_at)); ?></td>
                                    <td data-label="TRX" class="font-weight-bold"><?php echo e($trx->trx); ?></td>
                                    <td data-label="Amount" class="budget">
                                        <strong <?php if($trx->trx_type == '+'): ?> class="text-success" <?php else: ?> class="text-danger" <?php endif; ?>> <?php echo e(($trx->trx_type == '+') ? '+':'-'); ?> <?php echo e(getAmount($trx->amount)); ?> <?php echo e($general->cur_text); ?></strong>
                                    </td>
                                    <td data-label="Charge" class="budget"><?php echo e($general->cur_sym); ?> <?php echo e(getAmount($trx->charge)); ?> </td>
                                    <td data-label="Post Balance"><?php echo e($trx->post_balance +0); ?> <?php echo e($general->cur_text); ?></td>
                                    <td data-label="Detail"><?php echo e($trx->details); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e($empty_message); ?></td>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>
            </div><!-- card end -->
        </div>
    </div>

    <div class="row mb-none-30 mt-5">
        <div class="col-xl-4 col-lg-6 mb-30">
            <div class="card overflow-hidden">
                <div class="card-body">
                    <h5 class="card-title"><?php echo app('translator')->get('Login By Browser'); ?></h5>
                    <canvas id="userBrowserChart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-6 mb-30">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo app('translator')->get('Login By OS'); ?></h5>
                    <canvas id="userOsChart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-6 mb-30">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo app('translator')->get('Login By Country'); ?></h5>
                    <canvas id="userCountryChart"></canvas>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

    <script src="<?php echo e(asset('assets/admin/js/vendor/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/vendor/chart.js.2.8.0.js')); ?>"></script>

    <script>
        'use strict'
            // apex-bar-chart js
        var options = {
            series: [{
                name: 'Total Deposit',
                data: [
                    <?php $__currentLoopData = $report['months']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(getAmount(@$depositsMonth->where('months',$month)->first()->depositAmount)); ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]
            }, {
                name: 'Total Withdraw',
                data: [
                    <?php $__currentLoopData = $report['months']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(getAmount(@$withdrawalMonth->where('months',$month)->first()->withdrawAmount)); ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]
            }],
            chart: {
                type: 'bar',
                height: 400,
                toolbar: {
                    show: false
                }
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '50%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: true
            },
            stroke: {
                show: true,
                width: 2,
                colors: ['transparent']
            },
            xaxis: {
                categories: <?php echo json_encode($report['months']->flatten(), 15, 512) ?>,
            },
            yaxis: {
                title: {
                    text: "<?php echo e(__($general->cur_sym)); ?>",
                    style: {
                        color: '#7c97bb'
                    }
                }
            },
            grid: {
                xaxis: {
                    lines: {
                        show: false
                    }
                },
                yaxis: {
                    lines: {
                        show: false
                    }
                },
            },
            fill: {
                opacity: 1
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return "<?php echo e(__($general->cur_sym)); ?>" + val + " "
                    }
                }
            }
        };

            var chart = new ApexCharts(document.querySelector("#apex-bar-chart"), options);
            chart.render();

    </script>






 <script>

        var ctx = document.getElementById('userBrowserChart');
        var myChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($chart['user_browser_counter']->keys(), 15, 512) ?>,
                datasets: [{
                    data: <?php echo e($chart['user_browser_counter']->flatten()); ?>,
                    backgroundColor: [
                        '#FF4500',
                        '#e52d27',
                        '#fba540',
                        '#e7505a',
                        '#5050bf',
                        '#8E44AD',
                        '#4f8a8b',
                        '#1f4068',
                        '#62760c',
                        '#be5683',
                        '#cf1b1b',
                        '#96bb7c',
                        '#d3de32',
                        '#e8505b',
                        '#24a19c',
                        '#3b6978',
                        '#b83b5e',
                        '#ff4301',
                        '#c4fb6d',
                        '#bac964',
                        '#fb7813',
                        '#3b6978',
                        '#f3c623',
                        '#127681',
                        '#562349',
                        '#1f4068',
                        '#035aa6',
                        '#95389e',
                        '#481380'
                    ],
                    borderColor: [
                        'rgba(231, 80, 90, 0.75)'
                    ],
                    borderWidth: 0,

                }]
            },
            options: {
                aspectRatio: 1,
                responsive: true,
                maintainAspectRatio: true,
                elements: {
                    line: {
                        tension: 0 // disables bezier curves
                    }
                },
                scales: {
                    xAxes: [{
                        display: false
                    }],
                    yAxes: [{
                        display: false
                    }]
                },
                legend: {
                    display: false,
                }
            }
        });



        var ctx = document.getElementById('userOsChart');
        var myChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($chart['user_os_counter']->keys(), 15, 512) ?>,
                datasets: [{
                    data: <?php echo e($chart['user_os_counter']->flatten()); ?>,
                    backgroundColor: [
                        '#FF4500',
                        '#e52d27',
                        '#fba540',
                        '#e7505a',
                        '#5050bf',
                        '#8E44AD',
                        '#4f8a8b',
                        '#1f4068',
                        '#62760c',
                        '#be5683',
                        '#cf1b1b',
                        '#96bb7c',
                        '#d3de32',
                        '#e8505b',
                        '#24a19c',
                        '#3b6978',
                        '#b83b5e',
                        '#ff4301',
                        '#c4fb6d',
                        '#bac964',
                        '#fb7813',
                        '#3b6978',
                        '#f3c623',
                        '#127681',
                        '#562349',
                        '#1f4068',
                        '#035aa6',
                        '#95389e',
                        '#481380'

                    ],
                    borderColor: [
                        'rgba(0, 0, 0, 0.05)'
                    ],
                    borderWidth: 0,

                }]
            },
            options: {
                aspectRatio: 1,
                responsive: true,
                elements: {
                    line: {
                        tension: 0 // disables bezier curves
                    }
                },
                scales: {
                    xAxes: [{
                        display: false
                    }],
                    yAxes: [{
                        display: false
                    }]
                },
                legend: {
                    display: false,
                }
            },
        });


        //Donut chart
        var ctx = document.getElementById('userCountryChart');
        var myChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($chart['user_country_counter']->keys(), 15, 512) ?>,
                datasets: [{
                    data: <?php echo e($chart['user_country_counter']->flatten()); ?>,
                    backgroundColor: [
                        '#FF4500',
                        '#e52d27',
                        '#fba540',
                        '#e7505a',
                        '#5050bf',
                        '#8E44AD',
                        '#4f8a8b',
                        '#1f4068',
                        '#62760c',
                        '#be5683',
                        '#cf1b1b',
                        '#96bb7c',
                        '#d3de32',
                        '#e8505b',
                        '#24a19c',
                        '#3b6978',
                        '#b83b5e',
                        '#ff4301',
                        '#c4fb6d',
                        '#bac964',
                        '#fb7813',
                        '#3b6978',
                        '#f3c623',
                        '#127681',
                        '#562349',
                        '#1f4068',
                        '#035aa6',
                        '#95389e',
                        '#481380',
                    ],
                    borderColor: [
                        'rgba(231, 80, 90, 0.75)'
                    ],
                    borderWidth: 3,

                }]
            },
            options: {
                aspectRatio: 1,
                responsive: true,
                elements: {
                    line: {
                        tension: 0 // disables bezier curves
                    }
                },
                scales: {
                    xAxes: [{
                        display: false
                    }],
                    yAxes: [{
                        display: false
                    }]
                },
                legend: {
                    display: false,
                }
            }
        });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>