 <?php
     $content = getContent('brands.content',true);
     $elements = getContent('brands.element',false);
 ?>
 <!-- brand section start -->
 <div class="brand-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-7">
          <h4 class="mb-3 text-lg-left text-center"><?php echo app('translator')->get($content->data_values->heading); ?></h4>
          <div class="brand-slider">
           <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="single-slide">
            <div class="brand-item">
              <img src="<?php echo e(getImage('assets/images/frontend/brands/'.$element->data_values->image,'137x43')); ?>" alt="image">
            </div>
            </div><!-- single-slide end -->
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div><!-- brand-slider end -->
        </div>
      </div>
    </div>
  </div>
  <!-- brand section end --><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/templates/basic/sections/brands.blade.php ENDPATH**/ ?>