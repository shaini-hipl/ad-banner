


<?php $__env->startSection('content'); ?>

<?php echo $__env->make($activeTemplate.'partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <section class="pt-100 pb-100">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="content-block">
            <?php
                echo $policy->data_values->content;
            ?>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/templates/basic/sections/policy.blade.php ENDPATH**/ ?>