<?php
    $bg = getContent('login.content',true)->data_values;
?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make($activeTemplate.'partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="pt-100 pb-100">
    <div class="container">
      <div class="account-area">
        <div class="row justify-content-center">
          <div class="col-lg-6 bg_img d-flex flex-wrap justify-content-center align-items-center" data-background="<?php echo e(getImage('assets/images/frontend/login/'.$bg->background_image,'1920x1080')); ?>">
            <div class="account-content text-center px-5 py-4">
              <h2 class="text-white title"><?php echo app('translator')->get('Reset Password'); ?></h2>
              <p class="para-white mt-3"><?php echo app('translator')->get('Please provide valid email'); ?></p>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="account-wrapper">
              <div class="tab-content mt-5" id="myTabContent">
                <div class="tab-pane fade show active" id="publisher" role="tabpanel" aria-labelledby="publisher-tab">
                  <form class="account-form" method="POST" action="<?php echo e(route('advertiser.password.reset')); ?>"">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                      <label><?php echo app('translator')->get('Email Address'); ?> <sup class="text-danger">*</sup></label>
                      <input type="email" name="email" placeholder="<?php echo app('translator')->get('Email Address'); ?>" class="form-control">
                    </div>
                    <button type="submit" class="cmn-btn w-100"><?php echo app('translator')->get('Send Password Reset Code'); ?></button>
                  </form>
                </div>
               
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.basic.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/templates/basic/advertiser/auth/passwords/email.blade.php ENDPATH**/ ?>