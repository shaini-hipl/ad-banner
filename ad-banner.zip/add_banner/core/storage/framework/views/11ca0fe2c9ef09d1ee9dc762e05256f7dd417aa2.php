<?php $__env->startSection('content'); ?>

<?php
    $content =  getContent('banner.content',true);

?>

 
    <!-- hero start -->
    <section class="hero bg_img" data-background="<?php echo e(asset('assets/images/frontend/banner/'.$content->data_values->background_image)); ?>">
        <div id="particles-js"></div>
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-10 text-center">
              <h2 class="hero__title text-white"><?php echo app('translator')->get($content->data_values->heading); ?></h2>
              <p class="para-white mt-3 hero__details"><?php echo app('translator')->get($content->data_values->short_details); ?></p>
              <div class="btn-group justify-content-center mt-4">
                
                  <a href="<?php echo e(route('publisher.login')); ?>" class="cmn-btn"><i class="las la-eye font-size--18px mr-2"></i><?php echo app('translator')->get('Become a Publisher'); ?></a>
                  <a href="<?php echo e(route('advertiser.login')); ?>" class="cmn-btn"><i class="las la-plus font-size--18px mr-2"></i><?php echo app('translator')->get('Become an Advertiser'); ?></a>
                
               
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- hero end -->
    


    <?php if($sections->secs != null): ?>
        <?php $__currentLoopData = json_decode($sections->secs); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make($activeTemplate.'sections.'.$sec, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script-lib'); ?>
<script src="<?php echo e(asset('assets/templates/basic')); ?>/js/vendor/particles.js"></script>
<script src="<?php echo e(asset('assets/templates/basic')); ?>/js/vendor/app.js"></script>    
<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/templates/basic/home.blade.php ENDPATH**/ ?>