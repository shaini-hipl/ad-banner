<?php $__env->startSection('panel'); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">
                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Ad Name'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Ad title'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Type'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Advertiser'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Impression'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Click'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $advertises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Ad Name'); ?>" class="text--primary"><?php echo e($advertise->ad_name); ?></td>
                                <td data-label="<?php echo app('translator')->get('Ad title'); ?>" class="text--primary"><?php echo e($advertise->ad_title); ?></td>
                                <td data-label="<?php echo app('translator')->get('Type'); ?>"><span class="text--small badge font-weight-normal <?php echo e($advertise->ad_type=='click'?'badge--primary':'badge--warning'); ?> "><?php echo e($advertise->ad_type); ?></span></td>
                                <td data-label="<?php echo app('translator')->get('Advertiser'); ?>"><a href="<?php echo e(route('admin.advertiser.details',$advertise->advertiser->id)); ?>"><?php echo e($advertise->advertiser->name); ?></a></td>
                                
                                <td data-label="<?php echo app('translator')->get('Impression'); ?>"><?php echo e($advertise->impression??'0'); ?></td>
                              
                                <td data-label="<?php echo app('translator')->get('Click'); ?>"><?php echo e($advertise->clicked??'0'); ?></td>
                               
                                <?php if($advertise->status): ?>
                                <td data-label="<?php echo app('translator')->get('Status'); ?>"><span class="text--small badge font-weight-normal badge--success"><?php echo app('translator')->get('Active'); ?></span></td>
                                <?php else: ?>
                                <td data-label="<?php echo app('translator')->get('Status'); ?>"><span class="text--small badge font-weight-normal badge--warning"><?php echo app('translator')->get('Deactive'); ?></span></td>
                                <?php endif; ?>
                                <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                    <a href="<?php echo e(route('admin.advertise.details',$advertise->id)); ?>" class="icon-btn" data-toggle="tooltip" title="<?php echo app('translator')->get('details'); ?>">
                                        <i class="las la-desktop text--shadow"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e($empty_message); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>
                <div class="card-footer py-4">
                    <?php echo e($advertises->links('admin.partials.paginate')); ?>

                </div>
            </div><!-- card end -->
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/admin/advertises/allAdvertises.blade.php ENDPATH**/ ?>