<?php $__env->startSection('content'); ?>
<?php echo $__env->make($activeTemplate.'partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="pt-100 pb-100">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="row mb-none-30 justify-content-center">
            <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4 col-md-6 mb-30">
              <div class="blog-post hover--effect-1 has-link">
                <a href="<?php echo e(route('blog.details',[$blog->id,str_slug($blog->data_values->title)])); ?>" class="item-link"></a>
                <div class="blog-post__thumb">
                  <img src="<?php echo e(getImage('assets/images/frontend/blog/'.'thumb_'.$blog->data_values->image,'318x212')); ?>" alt="image" class="w-100">
                </div>
                <div class="blog-post__content">
                  <ul class="blog-post__meta mb-3">
                    <li>
                      <i class="las la-calendar-day"></i>
                      <span><?php echo e(showDateTime($blog->created_at)); ?></span>
                    </li>
                  </ul>
                  <h4 class="blog-post__title"><?php echo e($blog->data_values->title); ?></h4>
                  <p>
                    <?php echo e(Str::limit(strip_tags($blog->data_values->content),50)); ?>


                  </p>
                  <span class="blog-post__icon"><?php echo app('translator')->get('Read More'); ?><i class="las la-arrow-right ml-2"></i></span>
                </div>
              </div>
            </div><!-- blog-post end -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
             <div class="col-md-12 mb-30 ">
                <h3 class="text-center"><?php echo app('translator')->get('Currently No Blogs Available!!'); ?></h3>
              </div><!-- blog-post end -->
              <?php endif; ?>
          </div>
        </div><!-- row end -->
          <div class="row">
            <div class="col-lg-12">
                <?php echo e($blogs->links()); ?>

            </div>
          </div><!-- row end -->
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/templates/basic/blog.blade.php ENDPATH**/ ?>