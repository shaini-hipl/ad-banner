   <?php
       $content = getContent('testimonial.content',true);
       $elements = getContent('testimonial.element',false);
   ?>
   
   <!-- overview section start -->
    <section class="overview-section bg_img" data-background="<?php echo e(getImage('assets/images/frontend/testimonial/'.$content->data_values->background_image,'1920x1080')); ?>">
        <div class="container">
          <div class="row justify-content-between">
            <div class="col-lg-4">
              <div class="video-part text-lg-left text-center">
                <a href="<?php echo e($content->data_values->video_link); ?>" data-rel="lightcase:myCollection" class="video-icon"><i class="las la-play"></i></a>
                <h4 class="caption text-white mt-3"><?php echo app('translator')->get($content->data_values->video_title); ?></h4>
              </div>
            </div>
            <div class="col-lg-5 mt-lg-0 mt-5">
              <div class="testimonial-wrapper bottom-minus">
                <h4 class="title text-white"><?php echo app('translator')->get($content->data_values->heading); ?></h4>
                <div class="testimonial-slider">
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <div class="single-slide">
                  <div class="testimonial-card">
                    <p class="para-white"><?php echo app('translator')->get($element->data_values->quote); ?></p>
                    <div class="client d-flex flex-wrap align-items-center mt-4">
                      <div class="thumb">
                        <img src="<?php echo e(getImage('assets/images/frontend/testimonial/'.$element->data_values->image,'65x65')); ?>" alt="image">
                      </div>
                      <div class="content">
                        <h6 class="name base--color"><?php echo e($element->data_values->client_name); ?></h6>
                        <span class="designation para-white font-size--14px"><?php echo e($element->data_values->designation); ?></span>
                      </div>
                    </div>
                  </div>
                </div><!-- single-slide end -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div><!-- testimonial-wrapper end -->
            </div>
          </div>
        </div>
      </section>
      <!-- overview section end --><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/templates/basic/sections/testimonial.blade.php ENDPATH**/ ?>