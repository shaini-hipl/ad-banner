<?php $__env->startSection('panel'); ?>

    <div class="row">

        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">
                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Ad Name'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Ad Type'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Width'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Height'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Ad Slug'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Ad Name'); ?>" class="text--primary"> <?php echo e($type->adName); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Ad Type'); ?>"><span
                                            class="text--small badge font-weight-normal badge--warning"><?php echo e($type->type); ?></span>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Width'); ?>"><span
                                            class="text--small badge font-weight-normal badge--dark"><?php echo e($type->width); ?><?php echo app('translator')->get('px'); ?></span>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Height'); ?>"><span
                                            class="text--small badge font-weight-normal badge--dark"><?php echo e($type->height); ?><?php echo app('translator')->get('px'); ?>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Ad Slug'); ?>"><?php echo e($type->slug); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Status'); ?>"><span
                                            class="text--small badge font-weight-normal <?php echo e($type->status ==1 ?'badge--success':'badge--warning'); ?>"><?php echo e($type->status == 1 ? 'Active':'Deactive'); ?></span>
                                    </td>
                                    <td data-label="Action">
                                        <button type="button" class="icon-btn btn--primary edit"
                                                data-name="<?php echo e($type->adName); ?>"
                                                data-type="<?php echo e($type->type); ?>"
                                                data-width="<?php echo e($type->width); ?>"
                                                data-height="<?php echo e($type->height); ?>"
                                                data-slug="<?php echo e($type->slug); ?>"
                                                data-status="<?php echo e($type->status); ?>"
                                                data-route="<?php echo e(route('admin.advertise.update.type',$type->id)); ?>">
                                            <i class="las la-pen text--shadow"></i>
                                        </button>
                                        
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e($empty_message); ?></td>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>

            </div><!-- card end -->
        </div>

        <!-- Add Modal -->
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <form action="<?php echo e(route('admin.advertise.add.type')); ?>" method="POST" enctype="multipart/form-data">
                    <div class="modal-content">
                        <div class="modal-header btn--primary">
                            <h5 class="modal-title text-white" id="exampleModalLabel"><?php echo app('translator')->get('Add new Type'); ?></h5>
                            <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group ">
                                        <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Ad Name'); ?><span
                                                class="text-danger">*</span></label>
                                        <input class="form-control" placeholder="<?php echo e(trans('Ad name')); ?>" type="text"
                                               name="adName" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Ad Type'); ?><span
                                                class="text-danger">*</span></label>
                                        <input class="form-control" placeholder="<?php echo e(trans('Ad Type')); ?>" type="text"
                                               name="adType" value="image" readonly required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Width'); ?><span
                                            class="text-danger">*</span></label>
                                    <div class="form-group  input-group has_append">
                                        <input type="text" class="form-control" placeholder="<?php echo e(trans('width')); ?>"
                                               name="width" id="width" required>
                                        <div class="input-group-append">
                                            <div class="input-group-text"><?php echo app('translator')->get('px'); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Height'); ?><span
                                            class="text-danger">*</span></label>
                                    <div class="form-group  input-group has_append">
                                        <input type="text" class="form-control" placeholder="<?php echo e(trans('height')); ?>"
                                               name="height" id="height" required>
                                        <div class="input-group-append">
                                            <div class="input-group-text"><?php echo app('translator')->get('px'); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Slug'); ?><span
                                                class="text-danger">*</span></label>
                                        <input class="form-control" type="text" placeholder="<?php echo e(trans('slug')); ?>"
                                               id="slug" name="slug" value="" required readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <li class="list-group-item d-flex justify-content-between align-items-center font-weight-bold">
                                    <?php echo app('translator')->get('Status:'); ?>
                                    <label class="switch">
                                        <input type="checkbox" name="status" id="checkbox">
                                        <div class="slider round"></div>
                                    </label>
                                </li>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                            <button type="submit" class="btn btn--primary"><?php echo app('translator')->get('Save changes'); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!--edit modal-->
        <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="modal-content">
                        <div class="modal-header btn--primary">
                            <h5 class="modal-title text-white" id="exampleModalLabel"><?php echo app('translator')->get('Edit Type'); ?></h5>
                            <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group ">
                                        <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Ad Name'); ?><span
                                                class="text-danger">*</span></label>
                                        <input class="form-control" placeholder="<?php echo app('translator')->get('ad name'); ?>" type="text"
                                               name="adName"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Ad Type'); ?><span
                                                class="text-danger">*</span></label>
                                        <input class="form-control" placeholder="<?php echo e(trans('type')); ?>" type="text"
                                               name="adType" value="" required readonly>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Width'); ?><span
                                            class="text-danger">*</span></label>
                                    <div class="form-group  input-group has_append">
                                        <input type="text" class="form-control" placeholder="<?php echo e(trans('width')); ?>" id="w"
                                               name="width" value="" required>
                                        <div class="input-group-append">
                                            <div class="input-group-text"><?php echo app('translator')->get('px'); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Height'); ?><span
                                            class="text-danger">*</span></label>
                                    <div class="form-group  input-group has_append">
                                        <input type="text" id="h" class="form-control" placeholder="<?php echo e(trans('height')); ?>"
                                               name="height" value="" required>
                                        <div class="input-group-append">
                                            <div class="input-group-text"><?php echo app('translator')->get('px'); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-control-label  font-weight-bold"><?php echo app('translator')->get('Slug'); ?><span
                                                class="text-danger">*</span></label>
                                        <input class="form-control" type="text" placeholder="<?php echo e(trans('slug')); ?>" id="s"
                                               name="slug" value="" required readonly>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <li class="list-group-item d-flex justify-content-between align-items-center font-weight-bold">
                                    <?php echo app('translator')->get(' Status:'); ?>
                                    <label class="switch">
                                        <input type="checkbox" name="status">
                                        <div class="slider round"></div>
                                    </label>
                                </li>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                            <button type="submit" class="btn btn--primary"><?php echo app('translator')->get('Save changes'); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    

    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('breadcrumb-plugins'); ?>
    <button type="button" class="btn btn--primary" data-toggle="modal" data-target="#addModal"><i
            class="fas fa-plus"></i>
        <?php echo app('translator')->get('Add new Type'); ?>
    </button>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        var input, input2;
        $('#width').on('keyup', function () {
            input = $(this).val();
            $('#slug').val(input);
            if (input == '') {
                $('#slug').val('');
            }
        });
        $('#height').on('keyup', function () {
            input2 = $(this).val();
            $('#slug').val(input + 'x' + input2);
            if (input2 == '') {
                $('#slug').val('');
            }
        })

        var input3, input4;
        $('#w').on('keyup', function () {
            input3 = $(this).val();
            $('#s').val(input3);
            if (input == '') {
                $('#s').val('');
            }
        });
        $('#h').on('keyup', function () {
            input4 = $(this).val();
            $('#s').val(input3 + 'x' + input4);
            if (input4 == '') {
                $('#s').val('');
            }
        })

        var modal = $('#editModal');
        $('.edit').on('click', function () {
            var name = $(this).data('name');
            var type = $(this).data('type')
            var width = $(this).data('width')
            var height = $(this).data('height')
            var slug = $(this).data('slug')
            var status = $(this).data('status')
            var route = $(this).data('route')

            modal.find('input[name=adName]').val(name)
            modal.find('input[name=adType]').val(type)
            modal.find('input[name=width]').val(width)
            modal.find('input[name=height]').val(height)
            modal.find('input[name=slug]').val(slug)
            if (status == 1) {
                modal.find('input[name=status]').attr('checked', 'checked')
            }
            modal.find('form').attr('action', route)
            modal.modal('show')
        })

       
    </script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/admin/advertises/adTypes.blade.php ENDPATH**/ ?>