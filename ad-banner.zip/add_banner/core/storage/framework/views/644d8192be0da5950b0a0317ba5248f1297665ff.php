

<?php $__env->startSection('content'); ?>
<?php echo $__env->make($activeTemplate.'partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--=======Blog Section Starts Here=======-->
    <section class="blog-details-section pt-100 pb-100">
        <div class="container">
          <div class="row">
            <div class="col-lg-8 col-md-8">
              <div class="blog-details-wrapper">
                <div class="blog-details__thumb">
                  <img src="<?php echo e(getImage('assets/images/frontend/blog/'.$blog->data_values->image,'730x486')); ?>" alt="image">
                  <div class="post__date">
                    <span class="date"><?php echo e(showDateTime($blog->created_at,'d')); ?></span>
                    <span class="month"><?php echo e(showDateTime($blog->created_at,'M')); ?></span>
                  </div>
                </div><!-- blog-details__thumb end -->
                <div class="blog-details__content">
                  <h4 class="blog-details__title"><?php echo app('translator')->get($blog->title); ?></h4>
                  <p><?php echo $blog->data_values->content ?></p>
                </div><!-- blog-details__content end -->
                <div class="blog-details__footer">
                  <h4 class="caption"><?php echo app('translator')->get('Share This Post'); ?></h4>
                  <ul class="social__links">
                    <li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(url()->current())); ?>"><i class="fab fa-facebook-f" target="_blank"></i></a></li>
                    <li><a href="https://twitter.com/intent/tweet?text=Post and Share &amp;url=<?php echo e(urlencode(url()->current())); ?>" target="_blank"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo e(urlencode(url()->current())); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                    
                  </ul>
                </div><!-- blog-details__footer end -->
              </div><!-- blog-details-wrapper end -->
             
              <div class="comment-form-area">
                <h3 class="title"><?php echo app('translator')->get('leave a comment'); ?></h3>
                <div class="fb-comments" data-href="<?php echo e(url()->current()); ?>" data-numposts="5" data-width="700"></div>
              </div><!-- comment-form-area end -->
            </div>
            <div class="col-lg-4 col-md-4">
              <div class="sidebar">
                <div class="widget">
                  <h5 class="widget__title"><?php echo app('translator')->get('Recent posts'); ?></h5>
                  <ul class="small-post-list">
                    <?php $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <li class="small-post">
                      <div class="small-post__thumb"><img src="<?php echo e(getImage('assets/images/frontend/blog/'.'thumb_'.$recent->data_values->image,'318x212')); ?>" alt="image"></div>
                      <div class="small-post__content">
                        <h5 class="post__title"><a href="<?php echo e(route('blog.details',[$recent->id,str_slug($recent->data_values->title)])); ?>"><?php echo e(Str::limit($recent->data_values->title,30)); ?></a></h5>
                      </div>
                    </li><!-- small-post end -->
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul><!-- small-post-list end -->
                </div>
                <div class="widget">
                  <h5 class="widget__title"><?php echo app('translator')->get('Site Statistics'); ?></h5>
                  <ul class="categories__list">

                    <li class="categories__item d-flex justify-content-between">
                        <?php echo app('translator')->get('Total Clicks'); ?> <span class="text-right ml-5 stat_text"><?php echo e(number_format_short($total_click+$stat->data_values->total_click)); ?></span>
                    </li>
                    <li class="categories__item d-flex justify-content-between">
                        <?php echo app('translator')->get('Total Impression'); ?> <span class="text-right ml-5 stat_text"><?php echo e(number_format_short($total_imp+$stat->data_values->total_impression)); ?></span>
                    </li>
                    <li class="categories__item d-flex justify-content-between">
                        <?php echo app('translator')->get('Total Advertiser'); ?> <span class="text-right ml-5 stat_text"><?php echo e(number_format_short($total_users+$stat->data_values->total_advertiser)); ?></span>
                    </li>
                    <li class="categories__item d-flex justify-content-between">
                        <?php echo app('translator')->get('Total Publisher'); ?> <span class="text-right ml-5 stat_text"><?php echo e(number_format_short($total_publisher+$stat->data_values->total_publisher)); ?></span>
                    </li>
                  </ul>
                </div><!-- widget end -->
               
               <!-- widget end -->
                
              </div><!-- sidebar end -->
            </div>
          </div>
        </div>
      </section>
      <!-- blog-details-section end -->


<!--=======Blog Section Ends Here=======-->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    
<style>
  .stat_text{
    color: #16c79a
  }
</style>

<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/templates/basic/blogDetails.blade.php ENDPATH**/ ?>