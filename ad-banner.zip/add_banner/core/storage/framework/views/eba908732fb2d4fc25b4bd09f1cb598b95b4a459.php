<?php
    $breadcrumb = getContent('breadcrumb.content',true);
?>

<section class="inner-hero bg_img" data-background="<?php echo e(getImage('assets/images/frontend/breadcrumb/'.$breadcrumb->data_values->background_image)); ?>">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6 text-center">
          <h2 class="page-title text-white"><?php echo e($page_title); ?></h2>
          <ul class="page-breadcrumb justify-content-center">
           
          </ul>
        </div>
      </div>
    </div>
  </section><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/templates/basic/partials/breadcrumb.blade.php ENDPATH**/ ?>