<?php
    
    $feature = getContent('features.content',true);
    $features = getContent('features.element',false);

?>
  <!-- feature section start -->
  <section class="pt-100 pb-100">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6">
          <div class="section-header text-center">
            <h2 class="section-title"><?php echo app('translator')->get($feature->data_values->heading); ?></h2>
            <p><?php echo app('translator')->get($feature->data_values->short_details); ?></p>
          </div>
        </div>
      </div>
      <div class="feature-item-wrapper">
        <div class="row mb-none-30">
        <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-2 col-md-3 col-sm-4 col-6 mb-30">
          <div class="feature-card text-center">
            <div class="feature-card__icon">
              <img src="<?php echo e(getImage('assets/images/frontend/features/'.$item->data_values->image,'65x65')); ?>" alt="icon">
            </div>
            <div class="feature-card__content">
              <h6 class="title"><?php echo app('translator')->get($item->data_values->feature_name); ?></h6>
            </div>
          </div><!-- feature-card end -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </section>
  <!-- feature section end --><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/templates/basic/sections/features.blade.php ENDPATH**/ ?>