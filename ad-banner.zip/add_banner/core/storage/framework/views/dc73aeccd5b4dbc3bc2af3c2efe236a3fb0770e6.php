<?php echo  tawkto() ?>
<?php echo  analytics() ?><?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>