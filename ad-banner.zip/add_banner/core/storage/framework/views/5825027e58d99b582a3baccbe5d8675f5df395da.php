
<!-- meta tags and other links -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php echo $__env->make('partials.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <title><?php echo e($general->sitename($page_title ?? '')); ?></title>
  <link rel="icon" type="image/png" href="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/favicon.png')); ?>" sizes="16x16">
  <!-- bootstrap 4  -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/templates/basic/css/vendor/bootstrap.min.css')); ?>">
  <!-- fontawesome 5  -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/templates/basic/css/all.min.css')); ?>">
  <!-- line-awesome webfont -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/templates/basic/css/line-awesome.min.css')); ?>">  
  <!-- animate css -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/templates/basic/css/vendor/animate.min.css')); ?>">
  <!-- slick slider css -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/templates/basic/css/vendor/slick.css')); ?>">
  <!-- gallery video popup plugin css -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/templates/basic/css/lightcase.css')); ?>">
  <!-- main css -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/templates/basic/css/main.css')); ?>">
  
  <link href="<?php echo e(asset('assets/templates/basic/css/color.php')); ?>?color=<?php echo e($general->base_color); ?>&color2=<?php echo e($general->secondary_color); ?>"rel="stylesheet" />

  <?php echo $__env->yieldPushContent('style-lib'); ?>
  <?php echo $__env->yieldPushContent('style'); ?>
</head>
  <body>
    <?php
        echo fbcomment();
    ?>
    <div class="preloader">
      <div class="preloader-container">
        <span class="animated-preloader"></span>
      </div>
    </div>
  
    <!-- scroll-to-top start -->
    <div class="scroll-to-top">
      <span class="scroll-icon">
        <i class="fa fa-rocket" aria-hidden="true"></i>
      </span>
    </div>
    <!-- scroll-to-top end -->
  <div class="page-wrapper">
      <!-- header-section start  -->
  <header class="header">
    <div class="header__bottom">
      <div class="container">
        <nav class="navbar navbar-expand-xl p-0 align-items-center">
          <a class="site-logo site-title" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="site-logo"></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="menu-toggle"></span>
          </button>
          <div class="collapse navbar-collapse mt-lg-0 mt-3" id="navbarSupportedContent">
            <ul class="navbar-nav main-menu ml-auto">
              <li> <a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
             
              <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a href="<?php echo e(route('pages',[$data->slug])); ?>"><?php echo e(trans($data->name)); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
              <li> <a href="<?php echo e(route('blog')); ?>"><?php echo app('translator')->get('Blog'); ?></a></li>
              <?php if(auth()->guard('publisher')->user() || auth()->guard('advertiser')->user()): ?>
               <li> <a href="<?php echo e(route('ticket')); ?>"><?php echo app('translator')->get('Contact'); ?></a></li>
               <?php else: ?>
               <li> <a href="<?php echo e(route('home.contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a></li>
              <?php endif; ?>
             </ul>
           
             <?php if(!auth()->guard('publisher')->user() && !auth()->guard('advertiser')->user()): ?>
             <div class="nav-right">
              <a href="<?php echo e(route('login')); ?>" class="cmn-btn btn-md"><?php echo app('translator')->get('Login'); ?></a>
             </div>
             <?php endif; ?>
          
             <div class="nav-right">
              <select class="select style--two mr-3 langSel">
                <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->code); ?>" <?php if(session('lang') == $item->code): ?> selected  <?php endif; ?>><?php echo e(__($item->name)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php if(auth()->guard('publisher')->user()): ?>
              <a href="<?php echo e(route('publisher.dashboard')); ?>" class="cmn-btn btn-md"><?php echo app('translator')->get('Dashboard'); ?></a>
              <?php endif; ?>

              <?php if(auth()->guard('advertiser')->user()): ?>
              <a href="<?php echo e(route('advertiser.dashboard')); ?>" class="cmn-btn btn-md"><?php echo app('translator')->get('Dashboard'); ?></a>
              <?php endif; ?>
              
             </div>
           </div>
         </nav>
       </div>
     </div><!-- header__bottom end -->
    </header>
  <!-- header-section end  -->

    <?php echo $__env->yieldContent('content'); ?>

        <!-- footer section start -->
     <?php echo $__env->make($activeTemplate.'partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <!-- footer section end -->
        </div> <!-- page-wrapper end -->
          <!-- jQuery library -->

        <?php echo $__env->make('admin.partials.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script src="<?php echo e(asset('assets/templates/basic/js/vendor/jquery-3.5.1.min.js')); ?>"></script>
        <!-- bootstrap js -->
        <script src="<?php echo e(asset('assets/templates/basic/js/vendor/bootstrap.bundle.min.js')); ?>"></script>
        <!-- gallery video popup plugin js -->
        <script src="<?php echo e(asset('assets/templates/basic/js/vendor/lightcase.js')); ?>"></script>
        <!-- slick slider js -->
        <script src="<?php echo e(asset('assets/templates/basic/js/vendor/slick.min.js')); ?>"></script>
        <!-- scroll animation -->
        <script src="<?php echo e(asset('assets/templates/basic/js/vendor/wow.min.js')); ?>"></script>
        <!-- main js -->
        <script src="<?php echo e(asset('assets/templates/basic/js/app.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/templates/basic/js/jquery.nice-select.min.js')); ?>"></script>
  
        <?php echo $__env->make('partials.plugins', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('script-lib'); ?>
        <?php echo $__env->yieldPushContent('script'); ?>

        <script>
          (function ($) {
              "use strict";
              $(document).on("change", ".langSel", function() {
                  window.location.href = "<?php echo e(url('/')); ?>/change/"+$(this).val() ;
              });
              $('.nic-select').niceSelect();
          })(jQuery);
        </script>

        </body>
    </html>
<?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/templates/basic/layouts/frontend.blade.php ENDPATH**/ ?>