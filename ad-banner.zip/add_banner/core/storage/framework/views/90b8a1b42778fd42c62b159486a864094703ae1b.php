<?php if(\App\Extension::where('act', 'custom-captcha')->where('status', 1)->first()): ?>
    <div class="form-group row ">
        <div class="col-md-12">
            <?php echo  getCustomCaptcha(48,'100%') ?>
        </div>
        <div class="col-md-12 mt-4">
            <input type="text" name="captcha" placeholder=" Enter Code" class="form-control">
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/vhosts/hipl-staging4.com/ad-banner.hipl-staging4.com/core/resources/views/templates/basic/partials/custom-captcha.blade.php ENDPATH**/ ?>