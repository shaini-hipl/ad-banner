<option value="93" data-country="Afghanistan" data-code="AF">@lang("+93")</option>
<option value="358" data-country="Åland Islands" data-code="AX">@lang("+358")</option>
<option value="355" data-country="Albania" data-code="AL">@lang("+355")</option>
<option value="213" data-country="Algeria" data-code="DZ">@lang("+213")</option>
<option value="1684" data-country="American Samoa" data-code="AS">@lang("+1684")</option>
<option value="376" data-country="Andorra" data-code="AD">@lang("+376")</option>
<option value="244" data-country="Angola" data-code="AO">@lang("+244")</option>
<option value="1264" data-country="Anguilla" data-code="AI">@lang("+1264")</option>
<option value="672" data-country="Antarctica" data-code="AQ">@lang("+672")</option>
<option value="1268" data-country="Antigua and Barbuda" data-code="AG">@lang("+1268")</option>
<option value="54" data-country="Argentina" data-code="AR">@lang("+54")</option>
<option value="374" data-country="Armenia" data-code="AM">@lang("+374")</option>
<option value="297" data-country="Aruba" data-code="AW">@lang("+297")</option>
<option value="61" data-country="Australia" data-code="AU">@lang("+61")</option>
<option value="43" data-country="Austria" data-code="AT">@lang("+43")</option>
<option value="994" data-country="Azerbaijan" data-code="AZ">@lang("+994")</option>
<option value="1242" data-country="Bahamas" data-code="BS">@lang("+1242")</option>
<option value="973" data-country="Bahrain" data-code="BH">@lang("+973")</option>
<option value="880" data-country="Bangladesh" data-code="BD">@lang("+880")</option>
<option value="1246" data-country="Barbados" data-code="BB">@lang("+1246")</option>
<option value="375" data-country="Belarus" data-code="BY">@lang("+375")</option>
<option value="32" data-country="Belgium" data-code="BE">@lang("+32")</option>
<option value="501" data-country="Belize" data-code="BZ">@lang("+501")</option>
<option value="229" data-country="Benin" data-code="BJ">@lang("+229")</option>
<option value="1441" data-country="Bermuda" data-code="BM">@lang("+1441")</option>
<option value="975" data-country="Bhutan" data-code="BT">@lang("+975")</option>
<option value="591" data-country="Bolivia, Plurinational State of bolivia" data-code="BO">@lang("+591")</option>
<option value="387" data-country="Bosnia and Herzegovina" data-code="BA">@lang("+387")</option>
<option value="267" data-country="Botswana" data-code="BW">@lang("+267")</option>
<option value="47" data-country="Bouvet Island" data-code="BV">@lang("+47")</option>
<option value="55" data-country="Brazil" data-code="BR">@lang("+55")</option>
<option value="246" data-country="British Indian Ocean Territory" data-code="IO">@lang("+246")</option>
<option value="673" data-country="Brunei Darussalam" data-code="BN">@lang("+673")</option>
<option value="359" data-country="Bulgaria" data-code="BG">@lang("+359")</option>
<option value="226" data-country="Burkina Faso" data-code="BF">@lang("+226")</option>
<option value="257" data-country="Burundi" data-code="BI">@lang("+257")</option>
<option value="855" data-country="Cambodia" data-code="KH">@lang("+855")</option>
<option value="237" data-country="Cameroon" data-code="CM">@lang("+237")</option>
<option value="1" data-country="Canada" data-code="CA">@lang("+1")</option>
<option value="238" data-country="Cape Verde" data-code="CV">@lang("+238")</option>
<option value=" 345" data-country="Cayman Islands" data-code="KY">@lang("+ 345")</option>
<option value="236" data-country="Central African Republic" data-code="CF">@lang("+236")</option>
<option value="235" data-country="Chad" data-code="TD">@lang("+235")</option>
<option value="56" data-country="Chile" data-code="CL">@lang("+56")</option>
<option value="86" data-country="China" data-code="CN">@lang("+86")</option>
<option value="61" data-country="Christmas Island" data-code="CX">@lang("+61")</option>
<option value="61" data-country="Cocos (Keeling) Islands" data-code="CC">@lang("+61")</option>
<option value="57" data-country="Colombia" data-code="CO">@lang("+57")</option>
<option value="269" data-country="Comoros" data-code="KM">@lang("+269")</option>
<option value="242" data-country="Congo" data-code="CG">@lang("+242")</option>
<option value="243" data-country="Congo, The Democratic Republic of the Congo" data-code="CD">@lang("+243")</option>
<option value="682" data-country="Cook Islands" data-code="CK">@lang("+682")</option>
<option value="506" data-country="Costa Rica" data-code="CR">@lang("+506")</option>
<option value="225" data-country="Cote d'Ivoire" data-code="CI">@lang("+225")</option>
<option value="385" data-country="Croatia" data-code="HR">@lang("+385")</option>
<option value="53" data-country="Cuba" data-code="CU">@lang("+53")</option>
<option value="357" data-country="Cyprus" data-code="CY">@lang("+357")</option>
<option value="420" data-country="Czech Republic" data-code="CZ">@lang("+420")</option>
<option value="45" data-country="Denmark" data-code="DK">@lang("+45")</option>
<option value="253" data-country="Djibouti" data-code="DJ">@lang("+253")</option>
<option value="1767" data-country="Dominica" data-code="DM">@lang("+1767")</option>
<option value="1849" data-country="Dominican Republic" data-code="DO">@lang("+1849")</option>
<option value="593" data-country="Ecuador" data-code="EC">@lang("+593")</option>
<option value="20" data-country="Egypt" data-code="EG">@lang("+20")</option>
<option value="503" data-country="El Salvador" data-code="SV">@lang("+503")</option>
<option value="240" data-country="Equatorial Guinea" data-code="GQ">@lang("+240")</option>
<option value="291" data-country="Eritrea" data-code="ER">@lang("+291")</option>
<option value="372" data-country="Estonia" data-code="EE">@lang("+372")</option>
<option value="251" data-country="Ethiopia" data-code="ET">@lang("+251")</option>
<option value="500" data-country="Falkland Islands (Malvinas)" data-code="FK">@lang("+500")</option>
<option value="298" data-country="Faroe Islands" data-code="FO">@lang("+298")</option>
<option value="679" data-country="Fiji" data-code="FJ">@lang("+679")</option>
<option value="358" data-country="Finland" data-code="FI">@lang("+358")</option>
<option value="33" data-country="France" data-code="FR">@lang("+33")</option>
<option value="594" data-country="French Guiana" data-code="GF">@lang("+594")</option>
<option value="689" data-country="French Polynesia" data-code="PF">@lang("+689")</option>
<option value="262" data-country="French Southern Territories" data-code="TF">@lang("+262")</option>
<option value="241" data-country="Gabon" data-code="GA">@lang("+241")</option>
<option value="220" data-country="Gambia" data-code="GM">@lang("+220")</option>
<option value="995" data-country="Georgia" data-code="GE">@lang("+995")</option>
<option value="49" data-country="Germany" data-code="DE">@lang("+49")</option>
<option value="233" data-country="Ghana" data-code="GH">@lang("+233")</option>
<option value="350" data-country="Gibraltar" data-code="GI">@lang("+350")</option>
<option value="30" data-country="Greece" data-code="GR">@lang("+30")</option>
<option value="299" data-country="Greenland" data-code="GL">@lang("+299")</option>
<option value="1473" data-country="Grenada" data-code="GD">@lang("+1473")</option>
<option value="590" data-country="Guadeloupe" data-code="GP">@lang("+590")</option>
<option value="1671" data-country="Guam" data-code="GU">@lang("+1671")</option>
<option value="502" data-country="Guatemala" data-code="GT">@lang("+502")</option>
<option value="44" data-country="Guernsey" data-code="GG">@lang("+44")</option>
<option value="224" data-country="Guinea" data-code="GN">@lang("+224")</option>
<option value="245" data-country="Guinea-Bissau" data-code="GW">@lang("+245")</option>
<option value="592" data-country="Guyana" data-code="GY">@lang("+592")</option>
<option value="509" data-country="Haiti" data-code="HT">@lang("+509")</option>
<option value="0" data-country="Heard Island and Mcdonald Islands" data-code="HM">@lang("+0")</option>
<option value="379" data-country="Holy See (Vatican City State)" data-code="VA">@lang("+379")</option>
<option value="504" data-country="Honduras" data-code="HN">@lang("+504")</option>
<option value="852" data-country="Hong Kong" data-code="HK">@lang("+852")</option>
<option value="36" data-country="Hungary" data-code="HU">@lang("+36")</option>
<option value="354" data-country="Iceland" data-code="IS">@lang("+354")</option>
<option value="91" data-country="India" data-code="IN">@lang("+91")</option>
<option value="62" data-country="Indonesia" data-code="ID">@lang("+62")</option>
<option value="98" data-country="Iran, Islamic Republic of Persian Gulf" data-code="IR">@lang("+98")</option>
<option value="964" data-country="Iraq" data-code="IQ">@lang("+964")</option>
<option value="353" data-country="Ireland" data-code="IE">@lang("+353")</option>
<option value="44" data-country="Isle of Man" data-code="IM">@lang("+44")</option>
<option value="972" data-country="Israel" data-code="IL">@lang("+972")</option>
<option value="39" data-country="Italy" data-code="IT">@lang("+39")</option>
<option value="1876" data-country="Jamaica" data-code="JM">@lang("+1876")</option>
<option value="81" data-country="Japan" data-code="JP">@lang("+81")</option>
<option value="44" data-country="Jersey" data-code="JE">@lang("+44")</option>
<option value="962" data-country="Jordan" data-code="JO">@lang("+962")</option>
<option value="7" data-country="Kazakhstan" data-code="KZ">@lang("+7")</option>
<option value="254" data-country="Kenya" data-code="KE">@lang("+254")</option>
<option value="686" data-country="Kiribati" data-code="KI">@lang("+686")</option>
<option value="850" data-country="Korea, Democratic People's Republic of Korea" data-code="KP">@lang("+850")</option>
<option value="82" data-country="Korea, Republic of South Korea" data-code="KR">@lang("+82")</option>
<option value="383" data-country="Kosovo" data-code="XK">@lang("+383")</option>
<option value="965" data-country="Kuwait" data-code="KW">@lang("+965")</option>
<option value="996" data-country="Kyrgyzstan" data-code="KG">@lang("+996")</option>
<option value="856" data-country="Laos" data-code="LA">@lang("+856")</option>
<option value="371" data-country="Latvia" data-code="LV">@lang("+371")</option>
<option value="961" data-country="Lebanon" data-code="LB">@lang("+961")</option>
<option value="266" data-country="Lesotho" data-code="LS">@lang("+266")</option>
<option value="231" data-country="Liberia" data-code="LR">@lang("+231")</option>
<option value="218" data-country="Libyan Arab Jamahiriya" data-code="LY">@lang("+218")</option>
<option value="423" data-country="Liechtenstein" data-code="LI">@lang("+423")</option>
<option value="370" data-country="Lithuania" data-code="LT">@lang("+370")</option>
<option value="352" data-country="Luxembourg" data-code="LU">@lang("+352")</option>
<option value="853" data-country="Macao" data-code="MO">@lang("+853")</option>
<option value="389" data-country="Macedonia" data-code="MK">@lang("+389")</option>
<option value="261" data-country="Madagascar" data-code="MG">@lang("+261")</option>
<option value="265" data-country="Malawi" data-code="MW">@lang("+265")</option>
<option value="60" data-country="Malaysia" data-code="MY">@lang("+60")</option>
<option value="960" data-country="Maldives" data-code="MV">@lang("+960")</option>
<option value="223" data-country="Mali" data-code="ML">@lang("+223")</option>
<option value="356" data-country="Malta" data-code="MT">@lang("+356")</option>
<option value="692" data-country="Marshall Islands" data-code="MH">@lang("+692")</option>
<option value="596" data-country="Martinique" data-code="MQ">@lang("+596")</option>
<option value="222" data-country="Mauritania" data-code="MR">@lang("+222")</option>
<option value="230" data-country="Mauritius" data-code="MU">@lang("+230")</option>
<option value="262" data-country="Mayotte" data-code="YT">@lang("+262")</option>
<option value="52" data-country="Mexico" data-code="MX">@lang("+52")</option>
<option value="691" data-country="Micronesia, Federated States of Micronesia" data-code="FM">@lang("+691")</option>
<option value="373" data-country="Moldova" data-code="MD">@lang("+373")</option>
<option value="377" data-country="Monaco" data-code="MC">@lang("+377")</option>
<option value="976" data-country="Mongolia" data-code="MN">@lang("+976")</option>
<option value="382" data-country="Montenegro" data-code="ME">@lang("+382")</option>
<option value="1664" data-country="Montserrat" data-code="MS">@lang("+1664")</option>
<option value="212" data-country="Morocco" data-code="MA">@lang("+212")</option>
<option value="258" data-country="Mozambique" data-code="MZ">@lang("+258")</option>
<option value="95" data-country="Myanmar" data-code="MM">@lang("+95")</option>
<option value="264" data-country="Namibia" data-code="NA">@lang("+264")</option>
<option value="674" data-country="Nauru" data-code="NR">@lang("+674")</option>
<option value="977" data-country="Nepal" data-code="NP">@lang("+977")</option>
<option value="31" data-country="Netherlands" data-code="NL">@lang("+31")</option>
<option value="599" data-country="Netherlands Antilles" data-code="AN">@lang("+599")</option>
<option value="687" data-country="New Caledonia" data-code="NC">@lang("+687")</option>
<option value="64" data-country="New Zealand" data-code="NZ">@lang("+64")</option>
<option value="505" data-country="Nicaragua" data-code="NI">@lang("+505")</option>
<option value="227" data-country="Niger" data-code="NE">@lang("+227")</option>
<option value="234" data-country="Nigeria" data-code="NG">@lang("+234")</option>
<option value="683" data-country="Niue" data-code="NU">@lang("+683")</option>
<option value="672" data-country="Norfolk Island" data-code="NF">@lang("+672")</option>
<option value="1670" data-country="Northern Mariana Islands" data-code="MP">@lang("+1670")</option>
<option value="47" data-country="Norway" data-code="NO">@lang("+47")</option>
<option value="968" data-country="Oman" data-code="OM">@lang("+968")</option>
<option value="92" data-country="Pakistan" data-code="PK">@lang("+92")</option>
<option value="680" data-country="Palau" data-code="PW">@lang("+680")</option>
<option value="970" data-country="Palestinian Territory, Occupied" data-code="PS">@lang("+970")</option>
<option value="507" data-country="Panama" data-code="PA">@lang("+507")</option>
<option value="675" data-country="Papua New Guinea" data-code="PG">@lang("+675")</option>
<option value="595" data-country="Paraguay" data-code="PY">@lang("+595")</option>
<option value="51" data-country="Peru" data-code="PE">@lang("+51")</option>
<option value="63" data-country="Philippines" data-code="PH">@lang("+63")</option>
<option value="64" data-country="Pitcairn" data-code="PN">@lang("+64")</option>
<option value="48" data-country="Poland" data-code="PL">@lang("+48")</option>
<option value="351" data-country="Portugal" data-code="PT">@lang("+351")</option>
<option value="1939" data-country="Puerto Rico" data-code="PR">@lang("+1939")</option>
<option value="974" data-country="Qatar" data-code="QA">@lang("+974")</option>
<option value="40" data-country="Romania" data-code="RO">@lang("+40")</option>
<option value="7" data-country="Russia" data-code="RU">@lang("+7")</option>
<option value="250" data-country="Rwanda" data-code="RW">@lang("+250")</option>
<option value="262" data-country="Reunion" data-code="RE">@lang("+262")</option>
<option value="590" data-country="Saint Barthelemy" data-code="BL">@lang("+590")</option>
<option value="290" data-country="Saint Helena, Ascension and Tristan Da Cunha" data-code="SH">@lang("+290")</option>
<option value="1869" data-country="Saint Kitts and Nevis" data-code="KN">@lang("+1869")</option>
<option value="1758" data-country="Saint Lucia" data-code="LC">@lang("+1758")</option>
<option value="590" data-country="Saint Martin" data-code="MF">@lang("+590")</option>
<option value="508" data-country="Saint Pierre and Miquelon" data-code="PM">@lang("+508")</option>
<option value="1784" data-country="Saint Vincent and the Grenadines" data-code="VC">@lang("+1784")</option>
<option value="685" data-country="Samoa" data-code="WS">@lang("+685")</option>
<option value="378" data-country="San Marino" data-code="SM">@lang("+378")</option>
<option value="239" data-country="Sao Tome and Principe" data-code="ST">@lang("+239")</option>
<option value="966" data-country="Saudi Arabia" data-code="SA">@lang("+966")</option>
<option value="221" data-country="Senegal" data-code="SN">@lang("+221")</option>
<option value="381" data-country="Serbia" data-code="RS">@lang("+381")</option>
<option value="248" data-country="Seychelles" data-code="SC">@lang("+248")</option>
<option value="232" data-country="Sierra Leone" data-code="SL">@lang("+232")</option>
<option value="65" data-country="Singapore" data-code="SG">@lang("+65")</option>
<option value="421" data-country="Slovakia" data-code="SK">@lang("+421")</option>
<option value="386" data-country="Slovenia" data-code="SI">@lang("+386")</option>
<option value="677" data-country="Solomon Islands" data-code="SB">@lang("+677")</option>
<option value="252" data-country="Somalia" data-code="SO">@lang("+252")</option>
<option value="27" data-country="South Africa" data-code="ZA">@lang("+27")</option>
<option value="211" data-country="South Sudan" data-code="SS">@lang("+211")</option>
<option value="500" data-country="South Georgia and the South Sandwich Islands" data-code="GS">@lang("+500")</option>
<option value="34" data-country="Spain" data-code="ES">@lang("+34")</option>
<option value="94" data-country="Sri Lanka" data-code="LK">@lang("+94")</option>
<option value="249" data-country="Sudan" data-code="SD">@lang("+249")</option>
<option value="597" data-country="Suriname" data-code="SR">@lang("+597")</option>
<option value="47" data-country="Svalbard and Jan Mayen" data-code="SJ">@lang("+47")</option>
<option value="268" data-country="Swaziland" data-code="SZ">@lang("+268")</option>
<option value="46" data-country="Sweden" data-code="SE">@lang("+46")</option>
<option value="41" data-country="Switzerland" data-code="CH">@lang("+41")</option>
<option value="963" data-country="Syrian Arab Republic" data-code="SY">@lang("+963")</option>
<option value="886" data-country="Taiwan" data-code="TW">@lang("+886")</option>
<option value="992" data-country="Tajikistan" data-code="TJ">@lang("+992")</option>
<option value="255" data-country="Tanzania, United Republic of Tanzania" data-code="TZ">@lang("+255")</option>
<option value="66" data-country="Thailand" data-code="TH">@lang("+66")</option>
<option value="670" data-country="Timor-Leste" data-code="TL">@lang("+670")</option>
<option value="228" data-country="Togo" data-code="TG">@lang("+228")</option>
<option value="690" data-country="Tokelau" data-code="TK">@lang("+690")</option>
<option value="676" data-country="Tonga" data-code="TO">@lang("+676")</option>
<option value="1868" data-country="Trinidad and Tobago" data-code="TT">@lang("+1868")</option>
<option value="216" data-country="Tunisia" data-code="TN">@lang("+216")</option>
<option value="90" data-country="Turkey" data-code="TR">@lang("+90")</option>
<option value="993" data-country="Turkmenistan" data-code="TM">@lang("+993")</option>
<option value="1649" data-country="Turks and Caicos Islands" data-code="TC">@lang("+1649")</option>
<option value="688" data-country="Tuvalu" data-code="TV">@lang("+688")</option>
<option value="256" data-country="Uganda" data-code="UG">@lang("+256")</option>
<option value="380" data-country="Ukraine" data-code="UA">@lang("+380")</option>
<option value="971" data-country="United Arab Emirates" data-code="AE">@lang("+971")</option>
<option value="44" data-country="United Kingdom" data-code="GB">@lang("+44")</option>
<option value="1" data-country="United States" data-code="US">@lang("+1")</option>
<option value="598" data-country="Uruguay" data-code="UY">@lang("+598")</option>
<option value="998" data-country="Uzbekistan" data-code="UZ">@lang("+998")</option>
<option value="678" data-country="Vanuatu" data-code="VU">@lang("+678")</option>
<option value="58" data-country="Venezuela, Bolivarian Republic of Venezuela" data-code="VE">@lang("+58")</option>
<option value="84" data-country="Vietnam" data-code="VN">@lang("+84")</option>
<option value="1284" data-country="Virgin Islands, British" data-code="VG">@lang("+1284")</option>
<option value="1340" data-country="Virgin Islands, U.S." data-code="VI">@lang("+1340")</option>
<option value="681" data-country="Wallis and Futuna" data-code="WF">@lang("+681")</option>
<option value="967" data-country="Yemen" data-code="YE">@lang("+967")</option>
<option value="260" data-country="Zambia" data-code="ZM">@lang("+260")</option>
<option value="263" data-country="Zimbabwe" data-code="ZW">@lang("+263")</option>